// DO NOT EDIT

/// This is an extension point for custom native rules for Bazel.
///
/// - returns: Extra rules that are compiled with Bazel.
public func extraRules() -> [Rule.Type] { [] }

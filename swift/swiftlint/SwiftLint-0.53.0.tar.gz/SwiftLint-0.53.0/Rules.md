Rule documentation has moved [here](https://realm.github.io/SwiftLint/rule-directory.html).

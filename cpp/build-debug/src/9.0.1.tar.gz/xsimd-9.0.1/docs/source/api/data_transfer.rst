.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay 

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Data transfer
=============

.. doxygengroup:: batch_data_transfer
   :project: xsimd
   :content-only:

The following empty types are used for tag dispatching:

.. doxygenstruct:: xsimd::aligned_mode
   :project: xsimd

.. doxygenstruct:: xsimd::unaligned_mode
   :project: xsimd

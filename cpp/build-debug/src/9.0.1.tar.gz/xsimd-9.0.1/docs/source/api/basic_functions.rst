.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay 

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Basic functions
===============

.. _abs-function-reference:
.. doxygenfunction:: xsimd::abs(batch<T, A> const&)
   :project: xsimd

.. _fabs-function-reference:
.. doxygenfunction:: fabs
   :project: xsimd

.. _fmod-function-reference:
.. doxygenfunction:: fmod
   :project: xsimd

.. _remainder-func-ref:
.. doxygenfunction:: remainder
   :project: xsimd

.. _fma-function-reference:
.. doxygenfunction:: fma
   :project: xsimd

.. _fms-function-reference:
.. doxygenfunction:: fms
   :project: xsimd

.. _fnma-function-reference:
.. doxygenfunction:: fnma
   :project: xsimd

.. _fnms-function-reference:
.. doxygenfunction:: fnms
   :project: xsimd

.. _min-function-reference:
.. doxygenfunction:: min
   :project: xsimd

.. _max-function-reference:
.. doxygenfunction:: max
   :project: xsimd

.. _fmin-function-reference:
.. doxygenfunction:: fmin
   :project: xsimd

.. _fmax-function-reference:
.. doxygenfunction:: fmax
   :project: xsimd

.. _fdim-function-reference:
.. doxygenfunction:: fdim
   :project: xsimd

.. _sadd-function-reference:
.. doxygenfunction:: sadd
   :project: xsimd

.. _ssub-function-reference:
.. doxygenfunction:: ssub
   :project: xsimd

.. _clip-function-reference:
.. doxygenfunction:: clip
   :project: xsimd


.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Trigonometric functions
=======================

.. _sin-function-reference:
.. doxygenfunction:: sin
   :project: xsimd

.. _cos-function-reference:
.. doxygenfunction:: cos
   :project: xsimd

.. _sincos-func-ref:
.. doxygenfunction:: sincos
   :project: xsimd

.. _tan-function-reference:
.. doxygenfunction:: tan
   :project: xsimd

.. _asin-function-reference:
.. doxygenfunction:: asin
   :project: xsimd

.. _acos-function-reference:
.. doxygenfunction:: acos
   :project: xsimd

.. _atan-function-reference:
.. doxygenfunction:: atan
   :project: xsimd

.. _atan2-func-ref:
.. doxygenfunction:: atan2
   :project: xsimd


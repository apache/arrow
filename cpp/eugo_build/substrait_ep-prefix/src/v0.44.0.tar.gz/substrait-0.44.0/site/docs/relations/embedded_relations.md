# Embedded Relations

Pending.

Embedded relations allow a Substrait producer to define a set operation that will be embedded in the plan.

TODO: define lots of details about what interfaces, languages, formats, etc. Should reasonably be an extension of embedded user defined table functions.

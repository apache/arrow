# Substrait Validator

The [Substrait Validator](https://github.com/substrait-io/substrait-validator) is a tool 
used to validate substrait plans as well as print diagnostics information regarding the plan validity.

# Producer Tools

## Isthmus

[Isthmus](https://github.com/substrait-io/substrait-java/tree/main/isthmus) is an application
that serializes SQL to [Substrait Protobuf](https://substrait.io/serialization/binary_serialization/) 
via the Calcite SQL compiler.

# Substrait

Substrait is a new project focused on producing an independent description of data compute operations. It is composed primarily of:

1. A formal specification
2. A human readable text representation
3. A compact cross-language binary representation

For more details, please go to [substrait.io](https://substrait.io)

